using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class gameoverscript : MonoBehaviour
{
   public void getup()
   {
        SceneManager.LoadScene("Level 1");
        Debug.Log("pee");
   }

   public void giveup()
   {
        SceneManager.LoadScene("sot menu");
   }
}
