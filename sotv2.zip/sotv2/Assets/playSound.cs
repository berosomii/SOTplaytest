using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playSound : MonoBehaviour
{
 

    public AudioSource soundPlayer;
    

    public void playthesound()

    {
        soundPlayer.Play();
    }
}
