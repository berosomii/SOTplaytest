using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class lifeCount : MonoBehaviour
{
    public int LifeCount;
    private int numOfLives;


    void Start()
    {
        LifeCount = 4;
   

    }

    void Update()
    {
        if(LifeCount==0)
        {
    
            Debug.Log("Game Over!");
        }

        if (Input.GetKey(KeyCode.T))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
            Debug.Log("dead");
        }
    }
}