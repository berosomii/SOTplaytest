using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyAI : MonoBehaviour
{
    [SerializeField] float moveSpeed = 1.0f;

    Rigidbody2D myrb;
    BoxCollider2D mybc;
    void Start()
    {
        myrb = GetComponent<Rigidbody2D>();
        mybc = GetComponent<BoxCollider2D>();
    }

    // Update is called once per frame
    private bool isFacingRight()
    {
        return transform.localScale.x > Mathf.Epsilon;
    }

    void Update()
    {
        if (isFacingRight())
        {
            myrb.velocity = new Vector2(moveSpeed, 0);
        }
        else
        {
            myrb.velocity = new Vector2(-moveSpeed, 0);
        }
   
    }
   
    private void OnTriggerExit2D(Collider2D collision)
    {
        transform.localScale = new Vector2(-(Mathf.Sign(myrb.velocity.x)), transform.localScale.y);
    }
}
